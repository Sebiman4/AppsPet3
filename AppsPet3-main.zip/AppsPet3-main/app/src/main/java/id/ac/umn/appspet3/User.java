package id.ac.umn.appspet3;

public class User {

    public String name, email, Pass, Con_Pass;

    public User(String nama, String mail, String password, String passwordCon){
        this.name = name;
        this.email = email;
        this.Pass = Pass;
        this.Con_Pass = Con_Pass;
    }
}
