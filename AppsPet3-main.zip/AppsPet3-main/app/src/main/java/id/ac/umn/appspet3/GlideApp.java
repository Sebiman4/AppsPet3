package id.ac.umn.appspet3;

import com.bumptech.glide.module.AppGlideModule;
import com.bumptech.glide.annotation.GlideModule;

@GlideModule
public class GlideApp extends AppGlideModule{
}
